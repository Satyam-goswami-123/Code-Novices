import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api, setAuth } from '../api'

export default function Login(){
  const [u,setU] = useState('inspector')
  const [p,setP] = useState('inspector123')
  const [err,setErr] = useState('')
  const [busy,setBusy] = useState(false)
  const nav = useNavigate()
  const [isRegister, setIsRegister] = useState(false)
  const [fullName, setFullName] = useState('')
  const [role, setRole] = useState('investigator')
  const [regSuccess, setRegSuccess] = useState(null)

  const submit = async e => {
    e.preventDefault(); setErr(''); setBusy(true); setRegSuccess(null)
    try{
      if (isRegister) {
        const res = await api.register(fullName, role)
        setRegSuccess(res)
        setU(res.username)
        setP(res.temp_password)
        setIsRegister(false)
      } else {
        const r = await api.login(u,p)
        setAuth(r.access_token, r.user)
        nav('/')
      }
    }catch(e){ setErr(isRegister ? 'Registration failed' : 'Invalid credentials') }
    finally{ setBusy(false) }
  }
  return (
    <div className="login">
      <form className="card" onSubmit={submit}>
        <h2>KSP SCRB AI</h2>
        <div className="dim" style={{marginBottom:14}}>Conversational intelligence for Karnataka Police</div>
        
        {regSuccess && (
          <div style={{background:'#dcfce7', color:'#166534', padding:12, borderRadius:6, marginBottom:16, fontSize:14}}>
            <b>Registration Successful!</b><br/>
            Your Username: <code>{regSuccess.username}</code><br/>
            Temporary Password: <code>{regSuccess.temp_password}</code><br/>
            Please copy this password. You can change it after logging in.
          </div>
        )}

        <div style={{display:'flex',flexDirection:'column',gap:8}}>
          {isRegister ? (
            <>
              <label>Full Name<input value={fullName} onChange={e=>setFullName(e.target.value)} required autoFocus/></label>
              <label>Role
                <select value={role} onChange={e=>setRole(e.target.value)} style={{width:'100%', padding:'8px 12px', borderRadius:6, border:'1px solid #ddd', marginTop:4}}>
                  <option value="investigator">Investigator</option>
                  <option value="analyst">Analyst</option>
                  <option value="viewer">Viewer</option>
                  <option value="admin">Admin</option>
                </select>
              </label>
            </>
          ) : (
            <>
              <label>Username<input value={u} onChange={e=>setU(e.target.value)} autoFocus/></label>
              <label>Password<input type="password" value={p} onChange={e=>setP(e.target.value)}/></label>
            </>
          )}
          
          {err && <div style={{color:'#fca5a5',fontSize:13}}>{err}</div>}
          <button className="primary" disabled={busy} type="submit">{busy?(isRegister?'Registering…':'Signing in…'):(isRegister?'Register':'Sign in')}</button>
          
          <div style={{textAlign:'center', marginTop:8}}>
            <button type="button" onClick={() => { setIsRegister(!isRegister); setErr(''); setRegSuccess(null) }} style={{background:'none', border:'none', color:'#3b82f6', cursor:'pointer', fontSize:14, padding:4}}>
              {isRegister ? 'Already have an account? Sign in' : 'Need an account? Register'}
            </button>
          </div>
        </div>
        <div className="demos">
          <b>Demo accounts</b><br/>
          admin / admin123 &nbsp;·&nbsp; inspector / inspector123<br/>
          analyst / analyst123 &nbsp;·&nbsp; viewer / viewer123
        </div>
      </form>
    </div>
  )
}
