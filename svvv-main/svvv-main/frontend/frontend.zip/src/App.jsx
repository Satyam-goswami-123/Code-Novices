import React, { useEffect, useState } from 'react'
import { Routes, Route, Navigate, NavLink, useNavigate, useLocation } from 'react-router-dom'
import { getToken, getUser, clearAuth, api } from './api'
import { LayoutDashboard, MessageCircle, Search, Camera, Compass, TrendingUp, Network as NetworkIcon, BellRing, Route as RouteIcon, FlaskConical, Mic, ShieldCheck } from 'lucide-react'
import Login from './pages/Login.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Chat from './pages/Chat.jsx'
import Hotspots from './pages/Hotspots.jsx'
import Trends from './pages/Trends.jsx'
import Network from './pages/Network.jsx'
import Predict from './pages/Predict.jsx'
import Audit from './pages/Audit.jsx'
import Detective from './pages/Detective.jsx'
import Vision from './pages/Vision.jsx'
import Patrol from './pages/Patrol.jsx'
import PatrolRoute from './pages/PatrolRoute.jsx'
import WhatIf from './pages/WhatIf.jsx'
import AlertsToaster from './components/AlertsToaster.jsx'

function Shell({children}){
  const u = getUser()
  const nav = useNavigate()
  const [stats, setStats] = useState(null)
  const [showPasswordModal, setShowPasswordModal] = useState(false)
  const [oldPassword, setOldPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [passwordMsg, setPasswordMsg] = useState('')
  
  useEffect(()=>{ api.stats().then(setStats).catch(()=>{}) }, [])
  const logout = () => { clearAuth(); nav('/login') }
  
  const handleChangePassword = async (e) => {
    e.preventDefault()
    setPasswordMsg('Updating...')
    try {
      await api.changePassword(oldPassword, newPassword)
      setPasswordMsg('Password changed successfully!')
      setTimeout(() => { setShowPasswordModal(false); setPasswordMsg(''); setOldPassword(''); setNewPassword('') }, 2000)
    } catch (err) {
      setPasswordMsg('Failed: ' + (err.message || 'Incorrect old password'))
    }
  }
  const canAudit = u && u.role === 'admin'
  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">KSP SCRB AI <br/><small>Karnataka State Crime Records Bureau</small></div>
        <nav className="nav">
          <NavLink to="/" end><LayoutDashboard size={18} style={{marginRight: 8}} /> Dashboard</NavLink>
          <NavLink to="/chat"><MessageCircle size={18} style={{marginRight: 8}} /> Chat (EN / ಕನ್ನಡ)</NavLink>
          <NavLink to="/detective"><Search size={18} style={{marginRight: 8}} /> AI Detective</NavLink>
          <NavLink to="/vision"><Camera size={18} style={{marginRight: 8}} /> Vision Evidence</NavLink>
          <NavLink to="/hotspots"><Compass size={18} style={{marginRight: 8}} /> Hotspots</NavLink>
          <NavLink to="/trends"><TrendingUp size={18} style={{marginRight: 8}} /> Trends</NavLink>
          <NavLink to="/network"><NetworkIcon size={18} style={{marginRight: 8}} /> Network</NavLink>
          <NavLink to="/predict"><BellRing size={18} style={{marginRight: 8}} /> Predictive Alerts</NavLink>
          <NavLink to="/patrol-route"><RouteIcon size={18} style={{marginRight: 8}} /> Patrol Route</NavLink>

          <NavLink to="/whatif"><FlaskConical size={18} style={{marginRight: 8}} /> What-If Simulator</NavLink>
          <NavLink to="/patrol"><Mic size={18} style={{marginRight: 8}} /> Hands-free Patrol</NavLink>
          {canAudit && <NavLink to="/audit"><ShieldCheck size={18} style={{marginRight: 8}} /> Audit Chain</NavLink>}
        </nav>
        <div className="user-card">
          <div style={{color:'var(--text)',fontWeight:600}}>{u?.username}</div>
          <div>Role: <span className="badge">{u?.role}</span></div>
          {stats && <div style={{marginTop:6}}>Provider: <span className="pill ok">{stats.provider}</span></div>}
          <div style={{display:'flex', gap:8, marginTop:10}}>
            <button style={{flex:1, fontSize:12, padding:'6px'}} onClick={() => setShowPasswordModal(true)}>Change Password</button>
            <button style={{flex:1, fontSize:12, padding:'6px', background:'#333'}} onClick={logout}>Logout</button>
          </div>
        </div>
      </aside>
      
      {showPasswordModal && (
        <div style={{position:'fixed', inset:0, background:'rgba(0,0,0,0.5)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:9999}}>
          <form onSubmit={handleChangePassword} style={{background:'#fff', padding:24, borderRadius:8, width:300, display:'flex', flexDirection:'column', gap:12}}>
            <h3 style={{margin:0}}>Change Password</h3>
            <label style={{fontSize:13}}>Old Password<br/><input type="password" required value={oldPassword} onChange={e=>setOldPassword(e.target.value)} style={{width:'100%', padding:6, marginTop:4}}/></label>
            <label style={{fontSize:13}}>New Password<br/><input type="password" required value={newPassword} onChange={e=>setNewPassword(e.target.value)} style={{width:'100%', padding:6, marginTop:4}}/></label>
            {passwordMsg && <div style={{fontSize:13, color: passwordMsg.includes('success') ? 'green' : 'red'}}>{passwordMsg}</div>}
            <div style={{display:'flex', gap:8, marginTop:8}}>
              <button type="submit" className="primary" style={{flex:1}}>Submit</button>
              <button type="button" onClick={() => {setShowPasswordModal(false); setPasswordMsg('')}} style={{flex:1}}>Cancel</button>
            </div>
          </form>
        </div>
      )}

      <main className="main">
        {children}
        <AlertsToaster/>
      </main>
    </div>
  )
}

function Private({children}){
  const t = getToken()
  const loc = useLocation()
  if(!t) return <Navigate to="/login" state={{from:loc}} replace/>
  return <Shell>{children}</Shell>
}

export default function App(){
  return (
    <Routes>
      <Route path="/login" element={<Login/>}/>
      <Route path="/" element={<Private><Dashboard/></Private>}/>
      <Route path="/chat" element={<Private><Chat/></Private>}/>
      <Route path="/detective" element={<Private><Detective/></Private>}/>
      <Route path="/vision" element={<Private><Vision/></Private>}/>
      <Route path="/hotspots" element={<Private><Hotspots/></Private>}/>
      <Route path="/trends" element={<Private><Trends/></Private>}/>
      <Route path="/network" element={<Private><Network/></Private>}/>
      <Route path="/predict" element={<Private><Predict/></Private>}/>
      <Route path="/patrol-route" element={<Private><PatrolRoute/></Private>}/>
      <Route path="/whatif" element={<Private><WhatIf/></Private>}/>
      <Route path="/patrol" element={<Private><Patrol/></Private>}/>
      <Route path="/audit" element={<Private><Audit/></Private>}/>
    </Routes>
  )
}
