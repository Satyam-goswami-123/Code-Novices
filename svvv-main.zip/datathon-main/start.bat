@echo off
cd /d "%~dp0"
start "KSP Backend" powershell -NoExit -Command "cd backend; .\.venv\Scripts\Activate.ps1; python run.py"
timeout /t 2 /nobreak >nul
start "KSP Frontend" powershell -NoExit -Command "cd frontend; npm run dev"
timeout /t 5 /nobreak >nul
start http://localhost:5173
echo Started. Login: inspector / inspector123
