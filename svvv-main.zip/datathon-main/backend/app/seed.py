"""Seed synthetic Karnataka crime data."""
import random
from datetime import datetime, timedelta
from faker import Faker
from passlib.context import CryptContext
from .db import conn_ctx, init_db

fake = Faker("en_IN")
random.seed(7); Faker.seed(7)
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")

DISTRICTS = [
    ("Bengaluru Urban", 12.9716, 77.5946),
    ("Bengaluru Rural", 13.2846, 77.7066),
    ("Mysuru", 12.2958, 76.6394),
    ("Mangaluru", 12.9141, 74.8560),
    ("Hubballi-Dharwad", 15.3647, 75.1240),
    ("Belagavi", 15.8497, 74.4977),
    ("Kalaburagi", 17.3297, 76.8343),
    ("Ballari", 15.1394, 76.9214),
    ("Tumakuru", 13.3409, 77.1010),
    ("Shivamogga", 13.9299, 75.5681),
    ("Davanagere", 14.4644, 75.9218),
    ("Vijayapura", 16.8302, 75.7100),
    ("Raichur", 16.2076, 77.3463),
    ("Udupi", 13.3409, 74.7421),
    ("Chitradurga", 14.2226, 76.4034),
]

CRIME_TYPES = [
    ("Theft", ["379","380"], 3),
    ("Burglary", ["457","380"], 4),
    ("Robbery", ["392","394"], 6),
    ("Dacoity", ["395"], 8),
    ("Assault", ["323","324"], 5),
    ("Murder", ["302"], 10),
    ("Attempt to Murder", ["307"], 9),
    ("Kidnapping", ["363","364"], 8),
    ("Cheating/Fraud", ["420"], 4),
    ("Cybercrime", ["66","66C","66D"], 5),
    ("Drug Trafficking", ["NDPS 20","NDPS 21"], 7),
    ("Vehicle Theft", ["379"], 3),
    ("POCSO", ["POCSO 4","POCSO 6"], 9),
    ("Domestic Violence", ["498A"], 5),
    ("Riot", ["147","148"], 6),
    ("Arson", ["435","436"], 7),
    ("Counterfeiting", ["489A","489B"], 6),
    ("Extortion", ["384","385"], 6),
]

WEAPONS = ["None","Knife","Firearm","Blunt object","Vehicle","Explosive","Acid","Sharp weapon"]
MOTIVES = ["Monetary gain","Personal enmity","Gang rivalry","Domestic dispute","Property dispute","Drug-related","Unknown","Revenge","Political"]
OCCUPATIONS = ["Unemployed","Daily wage labourer","Driver","Mechanic","Student","Farmer","Shop owner","IT professional","Auto driver","Constable","Businessman","Vendor"]
EDU = ["Illiterate","Primary","Secondary","Higher Secondary","Graduate","Post-graduate"]
STATUSES = ["open","under_investigation","chargesheeted","closed"]


def seed(n_persons=1500, n_firs=6000, stations_per_district=8):
    init_db()
    with conn_ctx() as c:
        if c.execute("SELECT COUNT(*) FROM firs").fetchone()[0] > 0:
            print("Already seeded."); return

        # districts
        for i,(n,la,lg) in enumerate(DISTRICTS, start=1):
            c.execute("INSERT INTO districts(id,name,lat,lng) VALUES (?,?,?,?)",(i,n,la,lg))

        # stations
        sid = 1
        for di,(dn,la,lg) in enumerate(DISTRICTS, start=1):
            for k in range(stations_per_district):
                slat = la + random.uniform(-0.2,0.2)
                slng = lg + random.uniform(-0.2,0.2)
                c.execute("INSERT INTO stations(id,name,district_id,lat,lng) VALUES (?,?,?,?,?)",
                          (sid, f"{dn} PS-{k+1}", di, slat, slng)); sid += 1

        # users
        users = [
            ("admin","admin123","SCRB Admin","admin",None),
            ("inspector","inspector123","Insp. Rakesh Kumar","investigator",1),
            ("analyst","analyst123","Anita Rao","analyst",None),
            ("viewer","viewer123","Public Viewer","viewer",None),
        ]
        for u,p,n,r,s in users:
            c.execute("INSERT INTO users(username,password_hash,full_name,role,station_id) VALUES (?,?,?,?,?)",
                      (u, pwd.hash(p), n, r, s))

        # persons
        person_ids = []
        for _ in range(n_persons):
            gender = random.choice(["M","M","M","F","F","Other"])
            name = fake.name_male() if gender=="M" else fake.name_female() if gender=="F" else fake.name()
            age = random.randint(15, 70)
            d_id = random.randint(1, len(DISTRICTS))
            aliases = ", ".join(fake.first_name() for _ in range(random.randint(0,2))) or None
            c.execute("""INSERT INTO persons(full_name,age,gender,occupation,education,address,district_id,aliases)
                         VALUES (?,?,?,?,?,?,?,?)""",
                      (name, age, gender, random.choice(OCCUPATIONS), random.choice(EDU),
                       fake.address().replace("\n",", "), d_id, aliases))
            person_ids.append(c.execute("SELECT last_insert_rowid()").fetchone()[0])

        # FIRs
        station_rows = c.execute("SELECT id,district_id,lat,lng FROM stations").fetchall()
        start = datetime(2022,1,1); end = datetime(2026,6,1)
        span = (end-start).days
        hotspot_districts = {1,3,5,7}  # tilt crime toward these

        for i in range(n_firs):
            st = random.choice(station_rows)
            if random.random() < 0.45:
                # bias to hotspot
                hot = [s for s in station_rows if s["district_id"] in hotspot_districts]
                st = random.choice(hot)
            ct, sections, sev_base = random.choices(CRIME_TYPES, weights=[8,6,4,1,7,1,2,2,7,5,2,7,1,5,2,1,1,2])[0]
            occ = start + timedelta(days=random.randint(0,span), hours=random.randint(0,23))
            rep = occ + timedelta(hours=random.randint(0,72))
            fir_num = f"FIR/{occ.year}/{st['id']:04d}/{i+1:05d}"
            lat = st["lat"] + random.uniform(-0.05,0.05)
            lng = st["lng"] + random.uniform(-0.05,0.05)
            desc = f"{ct} reported in jurisdiction. {fake.sentence(nb_words=12)}"
            c.execute("""INSERT INTO firs(fir_number,station_id,district_id,crime_type,ipc_sections,
                         description,occurred_at,reported_at,lat,lng,status,severity,weapon_used,motive)
                         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                      (fir_num, st["id"], st["district_id"], ct, ",".join(sections),
                       desc, occ.isoformat(), rep.isoformat(), lat, lng,
                       random.choice(STATUSES), max(1, min(10, sev_base+random.randint(-1,1))),
                       random.choice(WEAPONS), random.choice(MOTIVES)))
            fir_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            # accused (1-4) — repeat offenders biased
            n_acc = random.choices([1,2,3,4], weights=[55,30,10,5])[0]
            for _ in range(n_acc):
                pid = random.choice(person_ids[:300]) if random.random()<0.4 else random.choice(person_ids)
                try:
                    c.execute("INSERT OR IGNORE INTO fir_accused(fir_id,person_id,role) VALUES (?,?,?)",
                              (fir_id, pid, random.choice(["main","accomplice","conspirator","abettor"])))
                except: pass
            # victims (0-2)
            for _ in range(random.choices([0,1,2],weights=[20,60,20])[0]):
                pid = random.choice(person_ids)
                try:
                    c.execute("INSERT OR IGNORE INTO fir_victims(fir_id,person_id) VALUES (?,?)",(fir_id,pid))
                except: pass

        # build associations: persons who appeared together as accused in any FIR
        rows = c.execute("""SELECT a.person_id p1, b.person_id p2, COUNT(*) c
                            FROM fir_accused a JOIN fir_accused b
                              ON a.fir_id=b.fir_id AND a.person_id<b.person_id
                            GROUP BY a.person_id, b.person_id""").fetchall()
        for r in rows:
            c.execute("""INSERT OR REPLACE INTO person_associations(person_a,person_b,relation,strength)
                         VALUES (?,?,?,?)""",
                      (r["p1"], r["p2"], "co-accused", float(r["c"])))

        print(f"Seeded {n_firs} FIRs, {n_persons} persons, {len(rows)} associations.")


if __name__ == "__main__":
    seed()
