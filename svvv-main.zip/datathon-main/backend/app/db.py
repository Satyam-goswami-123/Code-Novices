import sqlite3
from contextlib import contextmanager
from .config import settings

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT,
    role TEXT NOT NULL CHECK(role IN ('admin','investigator','analyst','viewer')),
    station_id INTEGER,
    email TEXT UNIQUE,
    mobile TEXT,
    rank TEXT,
    department TEXT,
    must_change_password BOOLEAN DEFAULT 0,
    last_login TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS districts (
    id INTEGER PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    lat REAL, lng REAL
);

CREATE TABLE IF NOT EXISTS stations (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    district_id INTEGER NOT NULL,
    lat REAL, lng REAL,
    FOREIGN KEY(district_id) REFERENCES districts(id)
);

CREATE TABLE IF NOT EXISTS persons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    age INTEGER,
    gender TEXT,
    occupation TEXT,
    education TEXT,
    address TEXT,
    district_id INTEGER,
    aliases TEXT,
    FOREIGN KEY(district_id) REFERENCES districts(id)
);

CREATE TABLE IF NOT EXISTS firs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fir_number TEXT UNIQUE NOT NULL,
    station_id INTEGER NOT NULL,
    district_id INTEGER NOT NULL,
    crime_type TEXT NOT NULL,
    ipc_sections TEXT,
    description TEXT,
    occurred_at TEXT NOT NULL,
    reported_at TEXT NOT NULL,
    lat REAL, lng REAL,
    status TEXT CHECK(status IN ('open','under_investigation','chargesheeted','closed')),
    severity INTEGER,
    weapon_used TEXT,
    motive TEXT,
    FOREIGN KEY(station_id) REFERENCES stations(id),
    FOREIGN KEY(district_id) REFERENCES districts(id)
);

CREATE TABLE IF NOT EXISTS fir_accused (
    fir_id INTEGER NOT NULL,
    person_id INTEGER NOT NULL,
    role TEXT,
    PRIMARY KEY(fir_id, person_id),
    FOREIGN KEY(fir_id) REFERENCES firs(id),
    FOREIGN KEY(person_id) REFERENCES persons(id)
);

CREATE TABLE IF NOT EXISTS fir_victims (
    fir_id INTEGER NOT NULL,
    person_id INTEGER NOT NULL,
    PRIMARY KEY(fir_id, person_id),
    FOREIGN KEY(fir_id) REFERENCES firs(id),
    FOREIGN KEY(person_id) REFERENCES persons(id)
);

CREATE TABLE IF NOT EXISTS person_associations (
    person_a INTEGER NOT NULL,
    person_b INTEGER NOT NULL,
    relation TEXT,
    strength REAL DEFAULT 1.0,
    PRIMARY KEY(person_a, person_b),
    FOREIGN KEY(person_a) REFERENCES persons(id),
    FOREIGN KEY(person_b) REFERENCES persons(id)
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT DEFAULT CURRENT_TIMESTAMP,
    user_id INTEGER,
    username TEXT,
    role TEXT,
    action TEXT,
    nl_query TEXT,
    sql_used TEXT,
    provider TEXT,
    success INTEGER,
    details TEXT
);

CREATE TABLE IF NOT EXISTS chat_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    meta TEXT,
    ts TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(session_id) REFERENCES chat_sessions(id)
);

CREATE TABLE IF NOT EXISTS otps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    otp_code TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS active_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    token_jti TEXT UNIQUE NOT NULL,
    ip_address TEXT,
    browser TEXT,
    device TEXT,
    login_time TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_firs_district ON firs(district_id);
CREATE INDEX IF NOT EXISTS idx_firs_type ON firs(crime_type);
CREATE INDEX IF NOT EXISTS idx_firs_occurred ON firs(occurred_at);
CREATE INDEX IF NOT EXISTS idx_acc_person ON fir_accused(person_id);
"""

def get_conn():
    conn = sqlite3.connect(settings.DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

@contextmanager
def conn_ctx():
    c = get_conn()
    try:
        yield c
        c.commit()
    finally:
        c.close()

def init_db():
    import os, shutil
    db_path = settings.DB_PATH
    if getattr(settings, "_in_catalyst", False) and getattr(settings, "DB_PATH", "").startswith("/tmp/"):
        # We are in Catalyst, and DB_PATH is in /tmp
        if not os.path.exists(db_path):
            bundled_db = os.path.join(os.path.dirname(__file__), "..", "ksp_crime.db")
            if os.path.exists(bundled_db):
                try:
                    shutil.copy2(bundled_db, db_path)
                    print("Copied bundled database to /tmp")
                except Exception as e:
                    print("Failed to copy database:", e)
    
    # Run schema script to ensure tables exist in case it was an empty file
    with conn_ctx() as c:
        c.executescript(SCHEMA)
